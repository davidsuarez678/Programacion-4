package com.example.demo.Model;

import jakarta.persistence.*;
@Entity
@Table(name="tbl_Pelota")
public class Pelota {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPelota;

    private String modelo;

    private int tamano;

    private String marca;

    public Long getIdPelota() {
        return idPelota;
    }

    public void setIdPelota(Long idPelota) {
        this.idPelota = idPelota;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getTamano() {
        return tamano;
    }

    public void setTamano(int tamano) {
        this.tamano = tamano;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
}