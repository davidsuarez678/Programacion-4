package com.example.demo.controller;


import com.example.demo.Model.Pelota;
import com.example.demo.Services.PelotaServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.model.IModel;

@Controller
@RequestMapping("/pelotas")
public class ControllerPelota {

    @Autowired
    private PelotaServices pelotaServices;


    @GetMapping
    public String ListarPelota(Model Model){
        Model.addAttribute("pelotas",pelotaServices.ListarPelotas());
        return "pelota-list";
    }

    @GetMapping("/CrearPelota")
    public String MostrarPelota(Model Model){
        Model.addAttribute("pelota",new Pelota());
        return "pelota-form";
    }

    @PostMapping
    public String CrearPelota(Pelota pelota){
        pelotaServices.GuardarPelota(pelota);
        return "redirect:/pelotas";
    }

    @GetMapping("/EditarPelota/{idpelota}")
    public String EditarPelota(@PathVariable long idpelota, Model model){
        Pelota pelota = pelotaServices.BuscarPorID(idpelota);
        model.addAttribute("pelota", pelota);
        return "pelota-form";
    }

    @GetMapping("/EliminarPelota/{idpelota}")
    public String EliminarPorID(@PathVariable long idpelota){
        pelotaServices.EliminarPelota(idpelota);
        return "redirect:/pelotas";
    }
}
