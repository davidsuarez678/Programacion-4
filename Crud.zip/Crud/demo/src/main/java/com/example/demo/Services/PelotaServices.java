package com.example.demo.Services;

import com.example.demo.Model.Pelota;
import com.example.demo.Repository.PelotaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PelotaServices {

      @Autowired
    private PelotaRepository pelotaRepository;
      public List <Pelota> ListarPelotas(){
          return pelotaRepository.findAll();
      }

      public Pelota GuardarPelota(Pelota pelota){
          return pelotaRepository.save(pelota);
      }

    public Pelota BuscarPorID(long pelota){
        return pelotaRepository.findById(pelota).orElse(null);
    }

    public void EliminarPelota(long Idpelota){
        pelotaRepository.deleteById(Idpelota);
    }
}
