package com.example.demo.Repository;

import com.example.demo.Model.Pelota;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PelotaRepository extends JpaRepository<Pelota,Long> {
}
